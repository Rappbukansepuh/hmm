const chatBox = document.getElementById("chat-box");
const userInput = document.getElementById("user-input");
const sendBtn = document.getElementById("send-btn");
const themeToggle = document.getElementById("theme-toggle");
const typingIndicator = document.getElementById("typing-indicator");

const responses = {
  "hai": "hai juga! 😊 ada yang bisa saya bantu?",
  "halo": "halo! apa yang bisa saya bantu hari ini?",
  "apa kabar": "saya baik-baik saja, terima kasih! bagaimana dengan kamu?",
  "siapa kamu": "saya adalah chatbot pintar yang siap membantu kamu! 👾",
  "siapa namamu": "saya adalah ai asisten yang dibuat oleh yudha yang siap membantu kamu.",
  "terima kasih": "sama-sama! senang bisa membantu. 😊",
  "selamat pagi": "selamat pagi! semoga harimu menyenangkan! 🌅",
  "selamat malam": "selamat malam! semoga tidurmu nyenyak. 😴",
  "berapa umurmu": "saya tidak punya umur, saya hanya sebuah program. 😁",
  "apa itu ai": "ai (artificial intelligence) adalah teknologi yang memungkinkan mesin untuk berpikir dan belajar seperti manusia.",
  "bantu saya": "tentu! apa yang bisa saya bantu hari ini?",
  "bisa kamu membantu saya dengan html?": "tentu! apa yang ingin kamu pelajari tentang html? saya siap membantu.",
  "bisa kamu bantu saya dengan css?": "tentu! css (cascading style sheets) digunakan untuk mendesain tampilan halaman web. apa yang ingin kamu ketahui?",
  "bisa kamu bantu saya dengan javascript?": "tentu! javascript digunakan untuk membuat halaman web interaktif. ada hal tertentu yang ingin kamu pelajari?",
  "apakah kamu pintar?": "saya dibekali dengan teknologi ai untuk membantu kamu! tapi saya masih belajar untuk menjadi lebih pintar. 😊",
  "siapa pembuatmu": "saya dibuat oleh yudha, yang ahli dalam bidang informatik.",
  "apa kegunaan ai?": "ai digunakan untuk memecahkan masalah yang rumit, membantu dalam pengambilan keputusan, serta mengotomatisasi berbagai tugas.",
  "apa yang bisa kamu lakukan?": "saya bisa membantu menjawab pertanyaan, memberi penjelasan tentang teknologi, memberikan saran, dan banyak lagi!",
  "kenapa kamu bisa berbicara?": "saya menggunakan pemrograman dan ai untuk memahami dan merespons percakapan dengan kamu. menarik, bukan?",
  "kapan kamu diciptakan?": "saya terus berkembang dan diperbarui, namun saya diciptakan oleh yudha dengan kecerdasan buatan yang terus belajar.",
  "apakah kamu bisa belajar?": "ya, saya terus belajar dari interaksi dengan pengguna dan pembaruan yang diberikan oleh pembuat saya.",
  "dapatkah kamu bermain game?": "saya bisa membantu menjelaskan aturan permainan atau memberikan saran strategi, tapi saya belum bisa bermain game seperti manusia.",
  "apakah kamu bisa memahami perasaan manusia?": "saya bisa mengenali kata-kata dan pola yang digunakan dalam percakapan, namun saya tidak bisa benar-benar merasakan emosi seperti manusia.",
  "bagaimana cara belajar html?": "untuk belajar html, kamu bisa mulai dengan membuat struktur dasar halaman web dan mempelajari tag-tag html seperti `<html>`, `<head>`, `<body>`, dan lainnya. saya bisa membantu memberikan contoh!",
  "apa itu css flexbox?": "css flexbox adalah layout model yang digunakan untuk mendistribusikan ruang antara elemen dalam sebuah container. ini membantu dalam membuat desain responsif dan fleksibel.",
  "apa yang dimaksud dengan javascript dom?": "dom (document object model) adalah antarmuka pemrograman yang memungkinkan javascript untuk mengubah struktur, gaya, dan konten html dalam halaman web secara dinamis.",
  "siapa presiden indonesia?": "presiden indonesia saat ini adalah Prabowo Subianto.",
  "apa ibu kota indonesia?": "ibu kota indonesia adalah jakarta.",
  "apakah kamu bisa mengingat percakapan?": "saya tidak dapat mengingat percakapan sebelumnya setelah sesi ini berakhir, karena saya tidak memiliki memori permanen.",
  "apa itu python?": "python adalah bahasa pemrograman yang mudah dipelajari dan digunakan dalam berbagai bidang, termasuk pengembangan web, data science, dan kecerdasan buatan.",
  "apakah kamu bisa membantu belajar python?": "tentu! saya bisa membantu menjelaskan konsep-konsep dasar python atau memberikan contoh kode.",
  "apa itu web development?": "web development adalah proses membuat dan mengembangkan situs web, mencakup desain, pengembangan front-end, dan back-end.",
  "siapa yang menemukan internet?": "internet ditemukan oleh tim peneliti yang dipimpin oleh vinton cerf dan bob kahn pada tahun 1970-an.",
  "default": "maaf, saya tidak mengerti pertanyaanmu. bisa kamu jelaskan lebih lanjut?",
  "apa itu blockchain?": "blockchain adalah teknologi yang memungkinkan penyimpanan data yang aman dan tidak dapat diubah, yang digunakan terutama untuk transaksi mata uang kripto.",
  "siapa tokoh terkenal dalam teknologi?": "beberapa tokoh terkenal dalam dunia teknologi adalah bill gates, steve jobs, mark zuckerberg, dan elon musk.",
  "apa itu cloud computing?": "cloud computing adalah layanan yang memungkinkan pengguna untuk menyimpan dan mengelola data serta menjalankan aplikasi melalui internet, tanpa perlu perangkat keras yang rumit.",
  "apa itu big data?": "big data adalah kumpulan data yang sangat besar dan kompleks yang tidak dapat dikelola atau diproses menggunakan metode tradisional.",
  "apa itu machine learning?": "machine learning adalah cabang dari kecerdasan buatan yang memungkinkan sistem untuk belajar dan berkembang berdasarkan data tanpa perlu diprogram secara eksplisit.",
  "apakah kamu bisa mengajarkan tentang machine learning?": "ya, saya bisa memberikan penjelasan dasar tentang machine learning dan bagaimana cara kerjanya. apa yang ingin kamu pelajari?",
  "bagaimana cara belajar machine learning?": "untuk belajar machine learning, kamu bisa mulai dengan memahami algoritma dasar seperti regresi linear dan pohon keputusan, dan kemudian melanjutkan ke topik yang lebih kompleks.",
  "siapa pencipta facebook?": "facebook diciptakan oleh mark zuckerberg bersama dengan teman-temannya eduardo saverin, andrew mccollum, dustin moskovitz, dan chris hughes.",
  "apa itu 5g?": "5g adalah generasi kelima dari teknologi jaringan seluler yang memberikan kecepatan internet yang lebih cepat, latensi lebih rendah, dan kapasitas yang lebih besar dibandingkan 4g.",
  "siapa pendiri apple?": "apple didirikan oleh steve jobs, steve wozniak, dan ronald wayne pada tahun 1976.",
  "apa itu augmented reality?": "augmented reality (ar) adalah teknologi yang menggabungkan dunia nyata dengan elemen virtual, seperti gambar atau informasi digital, dalam waktu nyata.",
  "apa itu virtual reality?": "virtual reality (vr) adalah teknologi yang menciptakan dunia digital yang dapat dijelajahi dan berinteraksi seolah-olah itu adalah dunia nyata.",
  "apa itu robotika?": "robotika adalah cabang teknik yang berkaitan dengan desain, konstruksi, dan penggunaan robot untuk menggantikan atau membantu pekerjaan manusia.",
  "apakah kamu bisa membantu dalam belajar matematika?": "tentu! saya bisa membantu dengan penjelasan konsep matematika dan memberikan contoh soal.",
  "apa itu data science?": "data science adalah bidang yang menggabungkan statistik, analisis data, dan pemrograman untuk mengekstrak wawasan dari data.",
  "siapa tokoh terkenal dalam data science?": "beberapa tokoh terkenal dalam data science adalah andrew ng, hadley wickham, dan dj patil."
};

// Tampilkan pesan
function appendMessage(content, className) {
  const messageWrapper = document.createElement("div");
  messageWrapper.className = className;

  const profilePic = document.createElement("div");
  profilePic.className = "profile-pic";

  const message = document.createElement("span");
  message.className = "message";
  message.textContent = content;

  messageWrapper.appendChild(profilePic);
  messageWrapper.appendChild(message);
  chatBox.appendChild(messageWrapper);
  chatBox.scrollTop = chatBox.scrollHeight;
}

// Proses input
sendBtn.addEventListener("click", () => {
  const userMessage = userInput.value.trim().toLowerCase();
  if (userMessage) {
    appendMessage(userMessage, "user-message");
    userInput.value = "";
    typingIndicator.style.display = "flex";

    setTimeout(() => {
      typingIndicator.style.display = "none";
      const botResponse = responses[userMessage] || "Maaf, saya belum mengerti.";
      appendMessage(botResponse, "bot-message");
    }, 1000);
  }
});

// Ubah tema
themeToggle.addEventListener("click", () => {
  document.body.classList.toggle("dark-mode");
  themeToggle.textContent = document.body.classList.contains("dark-mode") ? "☀️" : "🌙";
});